//
//  final.h
//

#ifndef FINAL_H
#define FINAL_H

#include <stddef.h>
#include <stdio.h>

struct list;

void final_code(FILE *stream, struct list *code);

#endif /* FINAL_H */
