//  include_iostream.h - Mock for system header <iostream>.

#include <fstream>

ifstream cin;
ofstream cout;
char endl;
